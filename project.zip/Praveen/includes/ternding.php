<div class="pinthure">	
			 <figure class="suwari img1">
  <img src="includes/includeimage/lightbulb-drawing-pencil.jpg" alt="sample38" />
  <div class="title">
    <div>
      <h2>TRENDING NOW</h2>
      <h4>Discover Now </h4>
    </div>
  </div>
  <figcaption>
    <p>The Focus and Accent On Your Spring Wardrobe</p>
  </figcaption>
  <a href="#"></a>
</figure>
<figure class="suwari img2">
  <img src="includes/includeimage/images.jpg" alt="sample38" />
  <div class="title">
    <div>
      <h2>TRENDING NOW</h2>
      <h4>Discover Now </h4>
    </div>
  </div>
  <figcaption>
    <p>The Focus and Accent On Your Spring Wardrobe</p>
  </figcaption>
  <a href="#"></a>
</figure>
<figure class="suwari img3">
  <img src="includes/includeimage/handicraft.jpg" alt="sample38" />
  <div class="title">
    <div>
      <h2>TRENDING NOW</h2>
      <h4>Discover Now </h4>
    </div>
  </div>
  <figcaption>
    <p>The Focus and Accent On Your Spring Wardrobe</p>
  </figcaption>
  <a href="#"></a>
</figure>
<figure class="suwari img4">
  <img src="includes/includeimage/1025415405-422686655_e9e99f3c-d363-4d64-a750-d2039ef105b4.jpg" alt="sample38" />
  <div class="title">
    <div>
      <h2>TRENDING NOW</h2>
      <h4>Discover Now </h4>
    </div>
  </div>
  <figcaption>
    <p>The Focus and Accent On Your Spring Wardrobe</p>
  </figcaption>
  <a href="#"></a>
</figure>
   </div>
