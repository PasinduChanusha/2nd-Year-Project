<button onclick="topFunction()" id="scr" title="Go to top">^</button>


<div class="container">

        <dev class="sear search"> 
        <?php include ("search/inde.php"); ?>  
             <!-- <input id="searchbar" class="searchbar" placeholder="Search in...">
      <a href="" id="press" class="press"><i class="fa fa-search" aria-hidden="true"></i></a> -->
        </dev>

        <div class="sear logo"> 
          <img src="../logo.png" alt="logo" width="200px" height="50px"> 
        </div>  
        </div>

    <hr>    
  <header>

    
  
      <div id="nave">
           <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="">Category</a>
            <ul class="dropdown">
                <li><a href="product.php">Home & Living</a></li>
                <li><a href="productart.php">Arts & Crafts</a></li>
                <li><a href="#.php">Tools & Home</a></li>
                <li><a href="productgardning.php">Home Gardening</a></li>
                <li><a href="#">Toys & Educational</a></li>
                <li><a href="#.php">Kitchen & Dining</a></li>
            </ul>
        </li>
        <li><a href="Login/praveen.php">Sell</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="postview/indexpostview.php">Timeline</a></li>
         <li><a href="">Login</a>
            <ul class="dropdown">
                <li><a href="Login/loginA.php">ADMIN</a></li>
                <li><a href="Login/loginD.php">DELIVERY</a></li>
                
            </ul>
        </li>


       
    </ul>  
      </div>
    </header>
    <hr>    
   
