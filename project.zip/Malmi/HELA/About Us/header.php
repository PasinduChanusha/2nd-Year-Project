<button class="sc" onclick="topFunction()" id="myBtn" title="Go to top">^</button>
<div class="container">
        <dev class="part search">   
             <input id="searchBar" class="searchbar" type="text" placeholder="Search in...">
      <a id="btnSearch" class="btn-search"><i class="fa fa-search" aria-hidden="true"></i></a>
        </dev>

        <div class="part logo"> 
            <img src=" ////" alt="">
        </div>

        <div class="part headericon">   
            <i class="fa fa-user-circle" aria-hidden="true"></i>
            <i class="fa fa-heart" aria-hidden="true"></i>
            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
        </div>
 
    </div>
    <hr>
<header>
      <div id="nav">
           <ul>
        <li><a href="../index.php">Home</a></li>
        <li><a href="servicepage.php">Services</a></li>
        <li><a href="">Category</a>
            <ul class="dropdown">
                <li><a href="catogery\cat1.php">Home & Living</a></li>
                <li><a href="catogery\cat2.php">Arts & Crafts</a></li>
                <li><a href="catogery\cat3.php">Tools & Home Improvement</a></li>
                <li><a href="catogery\cat4.php">Home Gardening</a></li>
                <li><a href="catogery\cat5.php">Toys & Educational</a></li>
                <li><a href="catogery\cat6.php">Kitchen & Dining</a></li>
            </ul>
        </li>
        <li><a href="">About us</a></li>
       
       
    </ul>  
      </div>
    </header>
    <hr>