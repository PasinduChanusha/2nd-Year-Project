<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/servicepage.css">
        <link type="text/css" rel="stylesheet" href="css\header.css">
     <link type="text/css" rel="stylesheet" href="css\footer.css">
        <title>detail page</title>
      
    </head>

    <body>
       
<?php include('php/header1.php');?>
<header>

  <div class="container">
    <section class="hero">
      
    </section>
  </div>
  
  <div class="container">
    <section class="projects">
      <div class="project-cards">

        <div class="p-card">
          <div class="card_img landing_img7"></div>
          <div class="pcard_info">
           
            <strong class="card-title">
              
                 Your Account
              </span>
            
             
            </strong>
          </div>
        </div>

        <div class="p-card">
          <div class="card_img landing_img8"></div>
          <div class="pcard_info">
           
            <strong class="card-title">
              <a href="ordertrackindex.php"><span class="project-name">
              Your Order
              </span>
              </a>
             
            </strong>
          </div>
        </div>

        <div class="p-card">
          <div class="card_img landing_img9"></div>
          <div class="pcard_info">
           
            <strong class="card-title">
              <span class="project-name">
                Payments
              </span>
             
            </strong>
          </div>
        </div>

        <div class="p-card">
          <div class="card_img landing_img1"></div>
          <div class="pcard_info">
           
            <strong class="card-title">
              <a href="Login/loginA.php"><span class="project-name">
              <span class="project-name">
                Edit website
              </span>
            </a>
             
            </strong>
          </div>
        </div>
        <div class="p-card">
          <div class="card_img landing_img10"></div>
          <div class="pcard_info">
           
            <strong class="card-title">
              <a href="Login/loginD.php"><span class="project-name">
                Delivery Services
              </span>
              </a>
             
            </strong>
          </div>
        </div>
 
        
      </div>
    </section>
  </div>
 

 <?php include('php/footer.php');?>
 <script src="js/scroll.js"></script>
</header>


    </body>
    
</html> 