<html>
<head>
  <script text="text/javascript" src="search/livesearch.js"></script>
</head>
<body>
<div>
<input   placeholder="Search in..." size="40" onkeyup="showResult(this.value)">
<div id="livesearch"></div>
</div>

</body>
</html>
 