<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
   <link rel="stylesheet" type="text/css" href="pro.css">
  <title>Document</title>
</head>
<!-- <style>
  
</style> -->
<body>
  
  <div class="product">
    <a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>


<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

<a href="view.php"><figure class="snip1268">
  <div class="image">
    <img src="a.jpg"/>
    <div class="icons">
      <a href="#"><i class="ion-star"></i></a>
      <a href="#"> <i class="ion-share"></i></a>
      <a href="#"> <i class="ion-search"></i></a>
    </div>
    <a href="cart.php" class="add-to-cart">Add to Cart</a>
  </div>
  <figcaption>
    <h2>Denim Shirt</h2>
    <p>My family is dysfunctional and my parents won't empower me. Consequently I'm not self actualized.</p>
    <div class="price">$65.00 </div>
  </figcaption>
</figure></a>

  </div>

<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>  

<body>
 
  
<!--  FOOTER START -->
  

  
</body>  

<!-- Thanks to Computer Conversations -->
</body>
</html>