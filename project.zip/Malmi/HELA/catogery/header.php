<header>
      <div id="nav">
           <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="">Services</a></li>
        <li><a href="">Category</a>
            <ul class="dropdown">
                <li><a href="cat1.php">Home & Living</a></li>
                <li><a href="cat2.php">Arts & Crafts</a></li>
                <li><a href="cat3.php">Tools & Home Improvement</a></li>
                <li><a href="cat4.php">Home Gardening</a></li>
                <li><a href="cat5.php">Toys & Educational</a></li>
                <li><a href="cat6.php">Kitchen & Dining</a></li>
            </ul>
        </li>
        <li><a href="">About us</a></li>
        <li><a href="">Contact</a></li>
    </ul>  
      </div>


    </header>