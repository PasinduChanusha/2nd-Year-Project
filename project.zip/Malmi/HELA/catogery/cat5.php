<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="cat.css">
	<title>home</title>
</head>
<style>
	


/* you can toggle the media screen view accordingly by changing the (max-width: px) to your convenience */

/* Thanks to Computer Conversations */
</style>
<body>

	<div class="container">
		<dev class="part search">	
			 <input id="searchBar" class="searchbar" type="text" placeholder="Search in...">
      <a id="btnSearch" class="btn-search"><i class="fa fa-search" aria-hidden="true"></i></a>
		</dev>

		<div class="part logo">	
			<img src="//cdn.shopify.com/s/files/1/0264/6972/8316/files/logo_456ad61d-ba6f-4e2b-98b4-824f533cc1e2_120x@2x.png?v=1571044369" alt="">
		</div>

		<div class="part headericon">	
			<i class="fa fa-user-circle" aria-hidden="true"></i>
			<i class="fa fa-heart" aria-hidden="true"></i>
			<i class="fa fa-shopping-cart" aria-hidden="true"></i>
		</div>
 
	</div>

	<hr>	
  <?php include('header.php');?>
    <div class="titel">
          <h1>technology</h1>
        </div>
    <!--
   <div class="imgcon">	
			 <figure class="snip1477 img1">
  <img src="https://cdn.shopify.com/s/files/1/0264/6972/8316/files/banner-1_f172658a-dcdd-4532-b2f1-6ca8d303c2d3.jpg?v=1567480733" alt="sample38" />
  <div class="title">
    <div>
      <h2>TRENDING NOW</h2>
      <h4>Discover Now </h4>
    </div>
  </div>
  <figcaption>
    <p>The Focus and Accent On Your Spring Wardrobe</p>
  </figcaption>
  <a href="#"></a>
</figure>
<figure class="snip1477 img2">
  <img src="https://cdn.shopify.com/s/files/1/0264/6972/8316/files/banner-2_ee88c516-9e51-4dba-aa76-64f330600796.jpg?v=1567480742" alt="sample38" />
  <div class="title">
    <div>
      <h2>TRENDING NOW</h2>
      <h4>Discover Now </h4>
    </div>
  </div>
  <figcaption>
    <p>The Focus and Accent On Your Spring Wardrobe</p>
  </figcaption>
  <a href="#"></a>
</figure>
<figure class="snip1477 img3">
  <img src="https://cdn.shopify.com/s/files/1/0264/6972/8316/files/banner-4_d73896b4-82aa-47dd-9a34-b96b3505c008.jpg?v=1582702186" alt="sample38" />
  <div class="title">
    <div>
      <h2>TRENDING NOW</h2>
      <h4>Discover Now </h4>
    </div>
  </div>
  <figcaption>
    <p>The Focus and Accent On Your Spring Wardrobe</p>
  </figcaption>
  <a href="#"></a>
</figure>
<figure class="snip1477 img4">
  <img src="https://cdn.shopify.com/s/files/1/0264/6972/8316/files/banner-5_bb00c4f0-0215-4ab1-aa94-1ab99bdcb709.jpg?v=1568970552" alt="sample38" />
  <div class="title">
    <div>
      <h2>TRENDING NOW</h2>
      <h4>Discover Now </h4>
    </div>
  </div>
  <figcaption>
    <p>The Focus and Accent On Your Spring Wardrobe</p>
  </figcaption>
  <a href="#"></a>
</figure>
   </div>
-->

    <?php //include("service.php"); ?>
    <?php// include("slie.php"); ?>
     <?php include("pro5.php"); ?>
    <!-- <img src="https://cdn.shopify.com/s/files/1/0264/6972/8316/files/banner-1_f172658a-dcdd-4532-b2f1-6ca8d303c2d3.jpg?v=1567480733" alt=""> -->
<!--   
<div class="button" id="previous">&lt;</div>
    <div class="button" id="next">&gt;</div>
-->
    <?php include('footer.php');?>
</body>
</html>
