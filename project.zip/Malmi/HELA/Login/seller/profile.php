<!DOCTYPE html>
<?php session_start(); ?>
<html>

<head>
    <link type="text/css" rel="stylesheet" href="profileS.css" />
    <script src="jquery.js"></script>
    <title>Seller Profile</title>
    <script>
    </script>

</head>

<body>

    <div class="coverpadx"><img src="https://cdn.thedesigninspiration.com/wp-content/uploads/2012/06/Facebook-Covers-004.jpg" width="1300px" height="400px" /></div>
    <div class="profilepic"></div>
    <div class="profilepicx"><img src="http://3.bp.blogspot.com/-CrWqZorCP2Y/UWrcGU_f_8I/AAAAAAAAClI/unXrkG-AEfs/s1600/facebook-profile-pictures36.jpg" height="140px" /></div>
    <div class="username"><? echo $SESSION_['shop_name'] ?> </div>
    <div class="box11"><a href="../../add/addproduct.php">Add Product</a></div>
    <div class="box12"><a href="sellerE.php">Edit Profile</div>
    <div class="box13"><a href="sellerE.php">Add Post</div>
        <div class="box14"><a href="logouts.php">Log Out</div>


    <div class="aboutpad">
        <ul>
            <li>
                <i> Works at Not Yet Working!! Am Still Studying!!</i>
            </li>

            <li>
                <i> Ginigathena Central College</i>
            </li>

            <li>
                <i> in Colombo, Sri Lanka</i>
            </li>

            <li>
                <i> From Colombo, Sri Lanka</i>
            </li>

            <li>
                <i> Exsample@gmail.com</i>
            </li>

            <li>
                <i> +9471560755</i>
            </li>
        </ul>
    </div>
</body>

</html>