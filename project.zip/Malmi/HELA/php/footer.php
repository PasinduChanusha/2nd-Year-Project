<div class="footer">
  <div class="inner-footer">

<!--  for company name and description -->
    <div class="footer-items">
      <h1>Healakam.lk</h1>
      <p>SriLanka's Premimum online handloom and handicrafts buying and seling site</p>
    </div>

    <div class="footer-items">
      <h3>Company Info</h3>
      <div class="border1"></div> <!--for the underline -->
        <ul>
          <a href="#"><li>About Helakam.lk</li></a>
          <a href="#"><li>Privacy Policy</li></a>
          <a href="#"><li>Terms & Conditions</li></a>
          <a href="#"><li>Cookie Policy</li></a>
        </ul>
    </div>

<!--  for quick links  -->
    <div class="footer-items">
      <h3>Quick Links</h3>
      <div class="border1"></div> <!--for the underline -->
        <ul>
          <a href="#"><li>Home</li></a>
          <a href="#"><li>Search</li></a>
          <a href="#"><li>Contact</li></a>
          <a href="#"><li>About</li></a>
        </ul>
    </div>

    


<!--  for contact us info -->
    <div class="footer-items">
      <h3>Reach us</h3>
      <div class="border1"></div>
        <ul>
          <li><i class="fa fa-map-marker" aria-hidden="true"></i>helakm.lk</li>
          <li><i class="fa fa-phone" aria-hidden="true"></i>0112xxxxxx</li>
          <li><i class="fa fa-envelope" aria-hidden="true"></i>helakmsrilanka@gmail.com</li>
        </ul> 
      
<!--   for social links -->
        
    </div>
  </div>
  
<!--   Footer Bottom start  -->
  <div class="footer-bottom">
    
  </div>
</div>